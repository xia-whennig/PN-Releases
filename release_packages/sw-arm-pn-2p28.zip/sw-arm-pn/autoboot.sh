#!/bin/bash
./progfippi > /var/www/autoboot.log
